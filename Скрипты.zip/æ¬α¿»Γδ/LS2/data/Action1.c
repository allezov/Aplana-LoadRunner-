Action1()
{

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_custom_request("cfr-v1-ru", 
		"URL=https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/ms-language-packs/records/cfr-v1-ru", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_concurrent_start(NULL);

	web_url("success.txt", 
		"URL=http://detectportal.firefox.com/success.txt", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t21.inf", 
		LAST);

	web_url("remote-settings.content-signature.mozilla.org-2020-01-23-16-17-19.chain", 
		"URL=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2020-01-23-16-17-19.chain", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t22.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("v1", 
		"URL=https://firefox.settings.services.mozilla.com/v1/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("success.txt_2", 
		"URL=http://detectportal.firefox.com/success.txt?ipv4", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t24.inf", 
		LAST);

	web_url("v1_2", 
		"URL=https://firefox.settings.services.mozilla.com/v1/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"null");

	web_custom_request("activity-stream", 
		"URL=https://tiles.services.mozilla.com/v4/links/activity-stream", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"locale\":\"ru\",\"topic\":\"activity-stream\",\"client_id\":\"d74e60b4-b04f-470a-bce1-8f53701c782d\",\"version\":\"71.0\",\"release_channel\":\"release\",\"addon_version\":\"20191202093317\",\"user_prefs\":251,\"action\":\"activity_stream_user_event\",\"event\":\"PAGE_TAKEOVER_DATA\",\"value\":{\"home_url_category\":\"search-engine\"},\"page\":\"about:home\",\"session_id\":\"n/a\",\"profile_creation_date\":18027,\"region\":\"RU\"}", 
		LAST);

	web_custom_request("downloads", 
		"URL=https://sba.yandex.net/downloads?client=navclient-auto-ffox&appver=71.0&pver=2.2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=text/plain", 
		"Body=ydx-badbinurl-shavar;a:11460-12406:s:12075-12542\nydx-malware-shavar;a:87879-88823:s:69165-69629\nydx-phish-shavar;a:27841-28789:s:27084-27553\nydx-unwanted-shavar;a:30632-31576:s:29806-30270\nydx-unwantedbinurl-shavar;a:2892-3870:s:1491-1951\n", 
		LAST);

	web_add_header("Origin", 
		"null");

	web_custom_request("ping-centre", 
		"URL=https://tiles.services.mozilla.com/v3/links/ping-centre", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"locale\":\"ru\",\"topic\":\"main\",\"client_id\":\"d74e60b4-b04f-470a-bce1-8f53701c782d\",\"version\":\"71.0\",\"release_channel\":\"release\",\"event\":\"AS_ENABLED\",\"value\":12,\"profile_creation_date\":18027,\"region\":\"RU\"}", 
		LAST);

	web_concurrent_start(NULL);

	web_url("L1ZOmsJ4jqPcqmpruoH1ZqhalhAWVEo89FQ6uvUcQPE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/L1ZOmsJ4jqPcqmpruoH1ZqhalhAWVEo89FQ6uvUcQPE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t29.inf", 
		LAST);

	web_url("KmEOYOvzFx-7YM89NKbFMzcRKpGUpvtN1MnUF6f4IuI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/KmEOYOvzFx-7YM89NKbFMzcRKpGUpvtN1MnUF6f4IuI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("vYttMMTDz5TAdi_CknxHjwTgxHxS37_kLizFcIQHXSI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/vYttMMTDz5TAdi_CknxHjwTgxHxS37_kLizFcIQHXSI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t31.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_websocket_connect("ID=0", 
		"URI=wss://push.services.mozilla.com/", 
		"Origin=wss://push.services.mozilla.com/", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_url("1.2", 
		"URL=https://snippets.cdn.mozilla.net/6/Firefox/71.0/20191202093317/WINNT_x86-msvc/ru/release-cck-yandex/Windows_NT%2010.0/yandex/1.2/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1576108829376\\\"\"},\"use_webpush\":true,\"uaid\":\"128db2798eea428e8a0c533f34ff1aaa\"}", 
		"IsBinary=0", 
		LAST);

	web_concurrent_start(NULL);

	web_url("4SOnhyCVphATn_jkMVWL9M8YjWdIsRtPmcYFUWl2JSY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/4SOnhyCVphATn_jkMVWL9M8YjWdIsRtPmcYFUWl2JSY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t34.inf", 
		LAST);

	web_url("GApITCQcpekKOtqPu4s_4leKcBZecBVlc_ku1aXmxQM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/GApITCQcpekKOtqPu4s_4leKcBZecBVlc_ku1aXmxQM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t35.inf", 
		LAST);

	web_url("2ejfH-md5RN09HSmsrUMb5zGEBlpNcjLKM99ClWAM2s=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/2ejfH-md5RN09HSmsrUMb5zGEBlpNcjLKM99ClWAM2s=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t36.inf", 
		LAST);

	web_url("wDTR_fsDKqJep4mf__ZNlZ4VVoCASTUIpx00oCrae4E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/wDTR_fsDKqJep4mf__ZNlZ4VVoCASTUIpx00oCrae4E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t37.inf", 
		LAST);

	web_url("R3MBMnrnJZK2fSZWxCc2D6N9Zg_eR4DcO0x7pCG_0zM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/R3MBMnrnJZK2fSZWxCc2D6N9Zg_eR4DcO0x7pCG_0zM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t38.inf", 
		LAST);

	web_url("vYhdbcWdffE-DI35WJG4j86Xy90a6VW4NLecP-7h_Cw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/vYhdbcWdffE-DI35WJG4j86Xy90a6VW4NLecP-7h_Cw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t39.inf", 
		LAST);

	web_url("tQhF2zU2uDlRSvbf9xEu-2ZyoN4GXF26gsdIu7KUZ1A=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/tQhF2zU2uDlRSvbf9xEu-2ZyoN4GXF26gsdIu7KUZ1A=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t40.inf", 
		LAST);

	web_url("vKHV2U5_MIs5IKpUCEh80eZ3xWMKHW0wD-TLll_xmxI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/vKHV2U5_MIs5IKpUCEh80eZ3xWMKHW0wD-TLll_xmxI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t41.inf", 
		LAST);

	web_url("rku19VMvw84izW--HXZJbYHwso_VU3NNH9DqkBnbdAg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/rku19VMvw84izW--HXZJbYHwso_VU3NNH9DqkBnbdAg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t42.inf", 
		LAST);

	web_url("PpTyF8eHMmoRZnkxWhpZNjj6VA2TAwtG8s0SJt8yWWk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/PpTyF8eHMmoRZnkxWhpZNjj6VA2TAwtG8s0SJt8yWWk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t43.inf", 
		LAST);

	web_url("W7V61vG7Knd6yc7i6sVYORG21pH1ImnpLVNGTHygsXg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/W7V61vG7Knd6yc7i6sVYORG21pH1ImnpLVNGTHygsXg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t44.inf", 
		LAST);

	web_url("9Y-ofCdR5McCKbNjzyO-1iWxA5P6NVKyv2qPV1F97Fo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/9Y-ofCdR5McCKbNjzyO-1iWxA5P6NVKyv2qPV1F97Fo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t45.inf", 
		LAST);

	web_url("CswkYjBieez_MBhhGO7Q2qYEDE8nVYgk9bUgxgWFs4k=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/CswkYjBieez_MBhhGO7Q2qYEDE8nVYgk9bUgxgWFs4k=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t46.inf", 
		LAST);

	web_url("Xij7BkP8k3OWn09_GKS93B-BEa2f05Ws8QL6TBs6aac=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Xij7BkP8k3OWn09_GKS93B-BEa2f05Ws8QL6TBs6aac=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t47.inf", 
		LAST);

	web_url("DQiWQ5TfZ1pBVUfadRNXUSBXVvV6WHH5xJ3EP3X76c8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/DQiWQ5TfZ1pBVUfadRNXUSBXVvV6WHH5xJ3EP3X76c8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t48.inf", 
		LAST);

	web_url("NCN5jwusaLeTGiRHNf4UcYC3KINIAHb-bnA6bw1EcF4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/NCN5jwusaLeTGiRHNf4UcYC3KINIAHb-bnA6bw1EcF4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t49.inf", 
		LAST);

	web_url("TR7BuyQHDlfZ7NszXYt_CvVD2hO9Q0-AEfZu2F8arAs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TR7BuyQHDlfZ7NszXYt_CvVD2hO9Q0-AEfZu2F8arAs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t50.inf", 
		LAST);

	web_url("_EO4Zwn3OfrZhiMYaLwQSCQFa5ZsnHiH8RyU7KizqNg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/_EO4Zwn3OfrZhiMYaLwQSCQFa5ZsnHiH8RyU7KizqNg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t51.inf", 
		LAST);

	web_url("PEWPvzlkLHF5Ev4V2rYJdB0oj1ScHMvfZCShtoDKL_8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/PEWPvzlkLHF5Ev4V2rYJdB0oj1ScHMvfZCShtoDKL_8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t52.inf", 
		LAST);

	web_url("iHsgyiejMYSoZt5Jon2t7D1KdcP51zz9-lXaPrtpse4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/iHsgyiejMYSoZt5Jon2t7D1KdcP51zz9-lXaPrtpse4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t53.inf", 
		LAST);

	web_url("0r956CYD13woEQQq4fZPzOHiABwhZLMB4Knv5JtSphY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/0r956CYD13woEQQq4fZPzOHiABwhZLMB4Knv5JtSphY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t54.inf", 
		LAST);

	web_url("QouGkFKiKpAOy1DBADf_aAxLpiIxuzvaeom3xJFuJrY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/QouGkFKiKpAOy1DBADf_aAxLpiIxuzvaeom3xJFuJrY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t55.inf", 
		LAST);

	web_url("A9jbSaQTwNNsTDBgcb_TpCdo-JCppiHECNUtXHN7zR8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/A9jbSaQTwNNsTDBgcb_TpCdo-JCppiHECNUtXHN7zR8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t56.inf", 
		LAST);

	web_url("u7I6JhUFAcg-eL-YoTo4VnfTIkH0wWfeO4T1MOphKQ0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/u7I6JhUFAcg-eL-YoTo4VnfTIkH0wWfeO4T1MOphKQ0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t57.inf", 
		LAST);

	web_url("L9EN7kxKSuVZ9XZ00bxznFA4WXSfxbVRYlI1sx153ik=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/L9EN7kxKSuVZ9XZ00bxznFA4WXSfxbVRYlI1sx153ik=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t58.inf", 
		LAST);

	web_url("N_q1wM6s_34EWYh1dbK_8-Uqk-e3SvL1a6cGx5V68Lc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/N_q1wM6s_34EWYh1dbK_8-Uqk-e3SvL1a6cGx5V68Lc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t59.inf", 
		LAST);

	web_url("TBXmQfUaVuyeribeX2xWZSoQLG1dKSAx_XiyQqYRD4o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TBXmQfUaVuyeribeX2xWZSoQLG1dKSAx_XiyQqYRD4o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t60.inf", 
		LAST);

	web_url("93u2cvb_IEmbq_U5cDIWG1xzl2uIVsIlaE5V5wc5Y9E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/93u2cvb_IEmbq_U5cDIWG1xzl2uIVsIlaE5V5wc5Y9E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("_EHjCQn2qV6QJIMXVmWcBaUbGYWRd5hdqAUrc8FD2N4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/_EHjCQn2qV6QJIMXVmWcBaUbGYWRd5hdqAUrc8FD2N4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t62.inf", 
		LAST);

	web_url("MjnPu5re9i6_T3T-wgme9U-rtCJSR9tODmjiE_ACznM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/MjnPu5re9i6_T3T-wgme9U-rtCJSR9tODmjiE_ACznM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t63.inf", 
		LAST);

	web_url("kijXoSltBX0fYhycmL1dvMzXRkndatgK8fRwShjQvLE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/kijXoSltBX0fYhycmL1dvMzXRkndatgK8fRwShjQvLE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t64.inf", 
		LAST);

	web_url("78DuDJgVdeKkx53vdiEfCnVsGcxZf_XHyOYScujGx6g=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/78DuDJgVdeKkx53vdiEfCnVsGcxZf_XHyOYScujGx6g=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t65.inf", 
		LAST);

	web_url("UjxwB55Tbpf58ALo1O1x1wkHnaDTXA8dz70uFWyQnf0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/UjxwB55Tbpf58ALo1O1x1wkHnaDTXA8dz70uFWyQnf0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t66.inf", 
		LAST);

	web_url("TnMnvxYWXbCVaDQDIDTB2hDe5E3Oi9HKEaxMLWyfQxg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TnMnvxYWXbCVaDQDIDTB2hDe5E3Oi9HKEaxMLWyfQxg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t67.inf", 
		LAST);

	web_url("F9XuCUMDeRWd-Qk3S-_vCFWH-OEcS-W3pJHX_MP7yIg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/F9XuCUMDeRWd-Qk3S-_vCFWH-OEcS-W3pJHX_MP7yIg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t68.inf", 
		LAST);

	web_url("yjKSUfkyzECLLhzjw0dcZiAkfCYBay13AbgDesT16LA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/yjKSUfkyzECLLhzjw0dcZiAkfCYBay13AbgDesT16LA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t69.inf", 
		LAST);

	web_url("EESZnQlNMhFrBveKlzS5tuHKqAPmzSymDVlv-CPzDmY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/EESZnQlNMhFrBveKlzS5tuHKqAPmzSymDVlv-CPzDmY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t70.inf", 
		LAST);

	web_url("Pw6o5NCGMRwSVlM_jrM0y6X9YIt-x1xKua9sS7jebcU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Pw6o5NCGMRwSVlM_jrM0y6X9YIt-x1xKua9sS7jebcU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t71.inf", 
		LAST);

	web_url("3NZITo3zLrh5B4_LrcI7tb4G4l_EYcMDT5HdIMgclDE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/3NZITo3zLrh5B4_LrcI7tb4G4l_EYcMDT5HdIMgclDE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t72.inf", 
		LAST);

	web_url("VFLy5oaJvKvlMmsIRTxi0LUUaYT_2RQupl46PDQyXfg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/VFLy5oaJvKvlMmsIRTxi0LUUaYT_2RQupl46PDQyXfg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t73.inf", 
		LAST);

	web_url("K5F0DR40no0FVQsFGk9AFIuMiF_qhubgMwv4fZYWxUM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/K5F0DR40no0FVQsFGk9AFIuMiF_qhubgMwv4fZYWxUM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t74.inf", 
		LAST);

	web_url("fxFi-PKxoehDGyL6CvzcrWRjKPrq4PsIHpxK60qlEyk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/fxFi-PKxoehDGyL6CvzcrWRjKPrq4PsIHpxK60qlEyk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t75.inf", 
		LAST);

	web_url("eaKKHfXPnu36r2yOOY2UsLN8qWgRJb6FBKq0jOpk8L0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/eaKKHfXPnu36r2yOOY2UsLN8qWgRJb6FBKq0jOpk8L0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t76.inf", 
		LAST);

	web_url("I7dNNqBYXfajft1cnFlrCshQ6WZbAabj4Fiz0-41B20=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/I7dNNqBYXfajft1cnFlrCshQ6WZbAabj4Fiz0-41B20=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t77.inf", 
		LAST);

	web_url("NokZJPxrIICEaBoinBjZh1S0eE0bXfVXH1IxQprAQKo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/NokZJPxrIICEaBoinBjZh1S0eE0bXfVXH1IxQprAQKo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t78.inf", 
		LAST);

	web_url("C2HuTWfP7eQu-4UQ0UniezUVBfdxzQLBsvnIm7qiSSo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/C2HuTWfP7eQu-4UQ0UniezUVBfdxzQLBsvnIm7qiSSo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t79.inf", 
		LAST);

	web_url("FuTk1YE6to7Tja11xWP9mtJ5s0NzNBVfDWBMV7fgI1s=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/FuTk1YE6to7Tja11xWP9mtJ5s0NzNBVfDWBMV7fgI1s=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t80.inf", 
		LAST);

	web_url("9Tyd0oTGQNV44qpAo7lawzO5OXS_0iLFm7oeTGP0Sqk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/9Tyd0oTGQNV44qpAo7lawzO5OXS_0iLFm7oeTGP0Sqk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t81.inf", 
		LAST);

	web_url("tOREecUtngYimsQ4oOJGVBcGXNq2p8p1mpEnFVm5woY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/tOREecUtngYimsQ4oOJGVBcGXNq2p8p1mpEnFVm5woY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t82.inf", 
		LAST);

	web_url("r53E5zB1rMpCdW2Bjgf0qmJEMFXHHY369ehXGg9SdI0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/r53E5zB1rMpCdW2Bjgf0qmJEMFXHHY369ehXGg9SdI0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t83.inf", 
		LAST);

	web_url("A1BS8L5D3X-7poQ9omP2JkwoMpU228Fb864rY6rk0bk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/A1BS8L5D3X-7poQ9omP2JkwoMpU228Fb864rY6rk0bk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t84.inf", 
		LAST);

	web_url("SgmrKEqm9akrL5vLZF_nswp5CmRbhpIXnSa3N6xcSlk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/SgmrKEqm9akrL5vLZF_nswp5CmRbhpIXnSa3N6xcSlk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t85.inf", 
		LAST);

	web_url("8glqe69wLLht2V6zElyPCfADQrZO_Vb1HppQq8JQ2HA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/8glqe69wLLht2V6zElyPCfADQrZO_Vb1HppQq8JQ2HA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t86.inf", 
		LAST);

	web_url("LOpiSY8Y4y3KWB1U5tn3Cx8CERgFY8v2ywhtv6yXHaQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/LOpiSY8Y4y3KWB1U5tn3Cx8CERgFY8v2ywhtv6yXHaQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t87.inf", 
		LAST);

	web_url("TFhTu6E0eZZViOkbAgnlkOV14xOZRnJot9e7qr6hj8o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TFhTu6E0eZZViOkbAgnlkOV14xOZRnJot9e7qr6hj8o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t88.inf", 
		LAST);

	web_url("Gm9YzgiHiO7oWARVHxM7ExY9cjv0Mw9Lvem6xQ4yHtE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Gm9YzgiHiO7oWARVHxM7ExY9cjv0Mw9Lvem6xQ4yHtE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t89.inf", 
		LAST);

	web_url("WFCqqPWoZ4QE0NAHaMpUuO2WWKPXDK4tTuXjkJfwcpI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/WFCqqPWoZ4QE0NAHaMpUuO2WWKPXDK4tTuXjkJfwcpI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t90.inf", 
		LAST);

	web_url("12lGBHxZseaU26uP_Y2GldXH1kBsUqckxp_7RwDM-u8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/12lGBHxZseaU26uP_Y2GldXH1kBsUqckxp_7RwDM-u8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t91.inf", 
		LAST);

	web_url("eF-L29oFsmBUKNryVW-_LGx2A1G4dEnFJw9To7mq-f0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/eF-L29oFsmBUKNryVW-_LGx2A1G4dEnFJw9To7mq-f0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t92.inf", 
		LAST);

	web_url("mOmsaULQiuPT-P0dH7zFQUYAr2yWKnQCqhYg7guG-c8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/mOmsaULQiuPT-P0dH7zFQUYAr2yWKnQCqhYg7guG-c8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t93.inf", 
		LAST);

	web_url("eRiAbTT3uPlyof5aIT_sxhkhFi0k8DNI5vgJdu3BLeA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/eRiAbTT3uPlyof5aIT_sxhkhFi0k8DNI5vgJdu3BLeA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t94.inf", 
		LAST);

	web_url("3_Sh1Q1-JX8M5TgVn4s4XhFHPH7cxfIVqydFIXCxRQg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/3_Sh1Q1-JX8M5TgVn4s4XhFHPH7cxfIVqydFIXCxRQg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t95.inf", 
		LAST);

	web_url("2vUBWRo3ZAi75acnc0CHD2T-RX8lU3zNR53tDIELudM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/2vUBWRo3ZAi75acnc0CHD2T-RX8lU3zNR53tDIELudM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t96.inf", 
		LAST);

	web_url("OXHjJJvVuQMb-F4GcKZGBLgIWd62lOatebVGNLvopqU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/OXHjJJvVuQMb-F4GcKZGBLgIWd62lOatebVGNLvopqU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t97.inf", 
		LAST);

	web_url("PkrnE-yc6e85ulmLFxMqB0T9cpGk_urXm09RhBPQkn0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/PkrnE-yc6e85ulmLFxMqB0T9cpGk_urXm09RhBPQkn0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t98.inf", 
		LAST);

	web_url("7EHHKemTQHKzulnMVn8AfXk9efhgnhjPs4fFn6xLz6E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/7EHHKemTQHKzulnMVn8AfXk9efhgnhjPs4fFn6xLz6E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t99.inf", 
		LAST);

	web_url("fv8-rSuo1ypBb4PcpBFovXdD0utWUce1FwR3V6SvEZ8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/fv8-rSuo1ypBb4PcpBFovXdD0utWUce1FwR3V6SvEZ8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t100.inf", 
		LAST);

	web_url("deQ4ULCq1w72b24DL5cGoFP3Uv55ts1i_H-9yN-ZykQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/deQ4ULCq1w72b24DL5cGoFP3Uv55ts1i_H-9yN-ZykQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t101.inf", 
		LAST);

	web_url("vfq2PIUOxvY_D1UIdhYBa6-1jkGGFxvaGrI20RlOy-o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/vfq2PIUOxvY_D1UIdhYBa6-1jkGGFxvaGrI20RlOy-o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t102.inf", 
		LAST);

	web_url("VXtoIkmqbHyRasZr851EEpqHAPjW6b3o5KiybAmFCAs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/VXtoIkmqbHyRasZr851EEpqHAPjW6b3o5KiybAmFCAs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t103.inf", 
		LAST);

	web_url("y6QrAy4MgYA6Pe3LhdjUqAmCt0VXG5CqSCxpOgGOkX0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/y6QrAy4MgYA6Pe3LhdjUqAmCt0VXG5CqSCxpOgGOkX0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t104.inf", 
		LAST);

	web_url("Aav28UmS6lPQfpdaGmPYs7Bg4DwK23Ej74osLhfz4W8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Aav28UmS6lPQfpdaGmPYs7Bg4DwK23Ej74osLhfz4W8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t105.inf", 
		LAST);

	web_url("IbfEVY6DCNQuso5wPSzSS-Salk8v-Ukd22io4MUiC3A=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/IbfEVY6DCNQuso5wPSzSS-Salk8v-Ukd22io4MUiC3A=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t106.inf", 
		LAST);

	web_url("EmaiG2XoUn9m7nNeCUOnL2yt-CymVhOMVdGNp21RLwk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/EmaiG2XoUn9m7nNeCUOnL2yt-CymVhOMVdGNp21RLwk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t107.inf", 
		LAST);

	web_url("d6onxEz37DiZQEQ2xC5vijUbwq7SdKSId226f2soM1Y=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/d6onxEz37DiZQEQ2xC5vijUbwq7SdKSId226f2soM1Y=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t108.inf", 
		LAST);

	web_url("eCBAm-vNOlUvY7pP43h0J9lJYH4AOPzOwP1cTCqDGz0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/eCBAm-vNOlUvY7pP43h0J9lJYH4AOPzOwP1cTCqDGz0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t109.inf", 
		LAST);

	web_url("Xg_BPI2Z3iBbDQx3J-6CPa1z0bYhLY2CCZqWjeqs4Sc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Xg_BPI2Z3iBbDQx3J-6CPa1z0bYhLY2CCZqWjeqs4Sc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t110.inf", 
		LAST);

	web_url("ArAUkbQTl_TUFpfibkIgZt40ObV56AxiQIhid2hgL_o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/ArAUkbQTl_TUFpfibkIgZt40ObV56AxiQIhid2hgL_o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t111.inf", 
		LAST);

	web_url("E-ggZu1vmX4Am9UWs9-rZzKT7uiWE1TWzMJLt9yhlgs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/E-ggZu1vmX4Am9UWs9-rZzKT7uiWE1TWzMJLt9yhlgs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t112.inf", 
		LAST);

	web_url("00oJVxH2rvEO1XheIDfldEBCNcul9kgg6S0WX14siIc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/00oJVxH2rvEO1XheIDfldEBCNcul9kgg6S0WX14siIc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t113.inf", 
		LAST);

	web_url("DJ9eoZ6JNLye3FtHEWc4dcuHNuerMax7CMJNTVvFN7A=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/DJ9eoZ6JNLye3FtHEWc4dcuHNuerMax7CMJNTVvFN7A=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t114.inf", 
		LAST);

	web_url("ROfiuG0px3JPng14eflUeMcXeCkHKrZ0Ijdvg8Vy5uo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/ROfiuG0px3JPng14eflUeMcXeCkHKrZ0Ijdvg8Vy5uo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t115.inf", 
		LAST);

	web_url("CUiIY0isoA2AzaKOcDWh8pbhVSikPe6Di-F2rq0OKVU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/CUiIY0isoA2AzaKOcDWh8pbhVSikPe6Di-F2rq0OKVU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t116.inf", 
		LAST);

	web_url("wOdAaXTr2kzNI7HjicnYK6IpBREk9PROxHELXjzWNx0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/wOdAaXTr2kzNI7HjicnYK6IpBREk9PROxHELXjzWNx0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t117.inf", 
		LAST);

	web_url("BBq4GEXTkIV8Zo3JLWLsz2-FRtn3QQaPAyh3w08tKIo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/BBq4GEXTkIV8Zo3JLWLsz2-FRtn3QQaPAyh3w08tKIo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t118.inf", 
		LAST);

	web_url("Yp-sob-r73ShzqSvO1c7OaTpoAL7O4J6ppt2CLuc-C8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Yp-sob-r73ShzqSvO1c7OaTpoAL7O4J6ppt2CLuc-C8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t119.inf", 
		LAST);

	web_url("DKYNsGwKWFNYltv6Jm5pWrxa_uW0S9Nce5Mbi_T9Haw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/DKYNsGwKWFNYltv6Jm5pWrxa_uW0S9Nce5Mbi_T9Haw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t120.inf", 
		LAST);

	web_url("eznIThAVsjh7WEhq852v4m9pbGkG6YMivRxDTUpeeqk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/eznIThAVsjh7WEhq852v4m9pbGkG6YMivRxDTUpeeqk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t121.inf", 
		LAST);

	web_url("49erep0zjaFdz5Cq13SJ9oHpvFbDw2rP5nbAQTbcbng=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/49erep0zjaFdz5Cq13SJ9oHpvFbDw2rP5nbAQTbcbng=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t122.inf", 
		LAST);

	web_url("ExkVPhSdtQhcp1mGb84XzeQkHruPY33eFN1iA4cWOVU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/ExkVPhSdtQhcp1mGb84XzeQkHruPY33eFN1iA4cWOVU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t123.inf", 
		LAST);

	web_url("3NXhajHBgM3hJMrG7GKLYJWasd_Tgu1qYAubKP8DrcM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/3NXhajHBgM3hJMrG7GKLYJWasd_Tgu1qYAubKP8DrcM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t124.inf", 
		LAST);

	web_url("_wiF9BUzIq9T7bFLYNg5ecqprNpe0VI94KD7qo_fPIk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/_wiF9BUzIq9T7bFLYNg5ecqprNpe0VI94KD7qo_fPIk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t125.inf", 
		LAST);

	web_url("K-wKHhg7fj1s6Xcj9Y4hdGsVlc8RmGl4MdIHRtGYrIk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/K-wKHhg7fj1s6Xcj9Y4hdGsVlc8RmGl4MdIHRtGYrIk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t126.inf", 
		LAST);

	web_url("TeXOrgxdRBIOR32A1V_Sq4kj_lVvne4KomWNI-RUPJQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TeXOrgxdRBIOR32A1V_Sq4kj_lVvne4KomWNI-RUPJQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t127.inf", 
		LAST);

	web_url("VM_-ooYZWZWYwocxJrYv9inWDvvMQjFWE1yqh7LV4Fw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/VM_-ooYZWZWYwocxJrYv9inWDvvMQjFWE1yqh7LV4Fw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t128.inf", 
		LAST);

	web_url("2zaaSVrPWKFSK9mAv3UXLB6cs1WdYCAwHt7JdEK-E40=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/2zaaSVrPWKFSK9mAv3UXLB6cs1WdYCAwHt7JdEK-E40=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t129.inf", 
		LAST);

	web_url("oCHIqadCBP_ITh91flmBgx0J8n8Kr3Q5mybT21gVOu4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/oCHIqadCBP_ITh91flmBgx0J8n8Kr3Q5mybT21gVOu4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t130.inf", 
		LAST);

	web_url("cbY5P_uu4GF01g4QBT1sPPf0UcsspfrYJ0ayBmPZlNM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/cbY5P_uu4GF01g4QBT1sPPf0UcsspfrYJ0ayBmPZlNM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t131.inf", 
		LAST);

	web_url("WofOsEeCPUYtM8AtfjfmGGPB8PDfhm9fhAky2hT7owc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/WofOsEeCPUYtM8AtfjfmGGPB8PDfhm9fhAky2hT7owc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t132.inf", 
		LAST);

	web_url("XA9XpOdxN3pI0vwnlKU9v0686WmGswB7uuA6mzozxGY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/XA9XpOdxN3pI0vwnlKU9v0686WmGswB7uuA6mzozxGY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t133.inf", 
		LAST);

	web_url("fWVdTl3Bd-xD8N_-phlaMsNKXAz-wz2Wn8oFavf2g28=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/fWVdTl3Bd-xD8N_-phlaMsNKXAz-wz2Wn8oFavf2g28=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t134.inf", 
		LAST);

	web_url("r8kGqCMCPrj8R27ZsMllyOmJkrLBLFNgmwoC1zwpNXA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/r8kGqCMCPrj8R27ZsMllyOmJkrLBLFNgmwoC1zwpNXA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t135.inf", 
		LAST);

	web_url("tGMc1T8I0JElSLpKfh01ft5u81dQagXQsGMQ_Cjd61o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/tGMc1T8I0JElSLpKfh01ft5u81dQagXQsGMQ_Cjd61o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t136.inf", 
		LAST);

	web_url("vIRF0LsCN7rf2g4yXdRKkauq1tZAbJ8pU1p6IWbpccY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/vIRF0LsCN7rf2g4yXdRKkauq1tZAbJ8pU1p6IWbpccY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t137.inf", 
		LAST);

	web_url("Vnbyhn8WEXXQMiTGXxtjYUMmiFDAt2F9ahyKw19uszM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Vnbyhn8WEXXQMiTGXxtjYUMmiFDAt2F9ahyKw19uszM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t138.inf", 
		LAST);

	web_url("iTJu_h_0vE0TXRuId7h8oxQMp6Vrns6_NiNYTCQO76g=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/iTJu_h_0vE0TXRuId7h8oxQMp6Vrns6_NiNYTCQO76g=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t139.inf", 
		LAST);

	web_url("Rnkx2PT27XTKaEwr_2Q6dIdgtjME_OttDwt9IQ0116c=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Rnkx2PT27XTKaEwr_2Q6dIdgtjME_OttDwt9IQ0116c=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t140.inf", 
		LAST);

	web_url("iAfURQw0oAvPJIEWFGv1mfXPty7mqZv9nSWV8rFVEL0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/iAfURQw0oAvPJIEWFGv1mfXPty7mqZv9nSWV8rFVEL0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t141.inf", 
		LAST);

	web_url("Z_XTPn3E1WfYnAmQDLvKv2BEz_EQHwgsQWqv3gfjpTk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/Z_XTPn3E1WfYnAmQDLvKv2BEz_EQHwgsQWqv3gfjpTk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t142.inf", 
		LAST);

	web_url("_s5Zm0PsZhfpvI2Z35oFk-3ts_UrpstmR3sA1MDabyA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/_s5Zm0PsZhfpvI2Z35oFk-3ts_UrpstmR3sA1MDabyA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t143.inf", 
		LAST);

	web_url("mP1mEaMlb5AN_BN6dibTUWENeevOYj6Jr0d8xPZd5ac=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/mP1mEaMlb5AN_BN6dibTUWENeevOYj6Jr0d8xPZd5ac=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t144.inf", 
		LAST);

	web_url("R9jW0SWOStG_teE7cj6UjRnB-hBa2C-ynB8y6fUfbMY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/R9jW0SWOStG_teE7cj6UjRnB-hBa2C-ynB8y6fUfbMY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t145.inf", 
		LAST);

	web_url("3MwHJ13O54yqfuYWiAdUU5HSLrOchxFVDYMimT8GUNI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/3MwHJ13O54yqfuYWiAdUU5HSLrOchxFVDYMimT8GUNI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t146.inf", 
		LAST);

	web_url("ICCr5J3HVhtG4OUTYXv8d-W3ZjaJsiXYkbDz5v9ykEE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/ICCr5J3HVhtG4OUTYXv8d-W3ZjaJsiXYkbDz5v9ykEE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t147.inf", 
		LAST);

	web_url("TGZKrTJ5caBW34UoShOGHuZgfLqim0KOuQOZ4Jj9d74=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/TGZKrTJ5caBW34UoShOGHuZgfLqim0KOuQOZ4Jj9d74=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t148.inf", 
		LAST);

	web_url("5YV5DDYpF2tbmA5DbiIYKSBlZselVM_v8YNfD3Mkd-E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/5YV5DDYpF2tbmA5DbiIYKSBlZselVM_v8YNfD3Mkd-E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t149.inf", 
		LAST);

	web_url("QNibqJm-FAFSoRGO6uzbY2F4pOu9NbDoLMf0IL88Jjk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-unwanted-software-download-shavar/QNibqJm-FAFSoRGO6uzbY2F4pOu9NbDoLMf0IL88Jjk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t150.inf", 
		LAST);

	web_url("LvVnA5hUSpo7mAnLhZae3SdpqSzd60V2NE0pfrEQWBw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/LvVnA5hUSpo7mAnLhZae3SdpqSzd60V2NE0pfrEQWBw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t151.inf", 
		LAST);

	web_url("snCDoyIEAOWqzTmE3cDk2JJKaRKepEW2F9yn33lKx2A=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/snCDoyIEAOWqzTmE3cDk2JJKaRKepEW2F9yn33lKx2A=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t152.inf", 
		LAST);

	web_url("u_bsou7JLowkObQoU_jhHjMnAMy2lTQfTqVVljQxSfo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/u_bsou7JLowkObQoU_jhHjMnAMy2lTQfTqVVljQxSfo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t153.inf", 
		LAST);

	web_url("2Z8mac597kKPJy8oT4F4R82lTQnckBT9ogsvx5zRj8s=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/2Z8mac597kKPJy8oT4F4R82lTQnckBT9ogsvx5zRj8s=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t154.inf", 
		LAST);

	web_url("a7OkeWVv-2AEEOlVXBYJMc0EijMZTU9t24sZbB14pbc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/a7OkeWVv-2AEEOlVXBYJMc0EijMZTU9t24sZbB14pbc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t155.inf", 
		LAST);

	web_url("fGu6vutZkpUTKrxdK7X00Q9EMHCd3iSPKDIwE3WBhEQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/fGu6vutZkpUTKrxdK7X00Q9EMHCd3iSPKDIwE3WBhEQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t156.inf", 
		LAST);

	web_url("LbyUzFFw_5LCtz1lCwD32vDeKA9rO8zpfBRPeGt_eMU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/LbyUzFFw_5LCtz1lCwD32vDeKA9rO8zpfBRPeGt_eMU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t157.inf", 
		LAST);

	web_url("ZAcXBKLnb0Z7IEGPMQKluigoaDNybqoRvJL0sdoUmxU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ZAcXBKLnb0Z7IEGPMQKluigoaDNybqoRvJL0sdoUmxU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t158.inf", 
		LAST);

	web_url("rELB3gPGy-aZlfBcG-jMW0mmySSFM4ik-cbRZdXVQxo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/rELB3gPGy-aZlfBcG-jMW0mmySSFM4ik-cbRZdXVQxo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t159.inf", 
		LAST);

	web_url("oZiPW9NjQVMhxGDnxTupLPi_vHk5ytNLPOi7h_AYac4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/oZiPW9NjQVMhxGDnxTupLPi_vHk5ytNLPOi7h_AYac4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t160.inf", 
		LAST);

	web_url("7oLYGo6NqWnNeGwLi5skwVzl9cXOA-WYz_zVMhffpac=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/7oLYGo6NqWnNeGwLi5skwVzl9cXOA-WYz_zVMhffpac=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t161.inf", 
		LAST);

	web_url("6iArUVtRnHr2swbiUFyFXiygTatJNBYX6QnnFt7Bc2E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/6iArUVtRnHr2swbiUFyFXiygTatJNBYX6QnnFt7Bc2E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t162.inf", 
		LAST);

	web_url("L7p9YasKCbnMx_KQVuYgSO7IG-8yfMCsmavFGU87IiM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/L7p9YasKCbnMx_KQVuYgSO7IG-8yfMCsmavFGU87IiM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t163.inf", 
		LAST);

	web_url("xhfX_gLiDT__6NPXFAJkGYixyh2Q8FR3eGKDI1uRI24=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/xhfX_gLiDT__6NPXFAJkGYixyh2Q8FR3eGKDI1uRI24=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t164.inf", 
		LAST);

	web_url("yZflVVXakv5DVaZkRlJ8xs2Idrsz2e3h7EtHCOjqpto=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/yZflVVXakv5DVaZkRlJ8xs2Idrsz2e3h7EtHCOjqpto=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t165.inf", 
		LAST);

	web_url("msVVn3XOU7NmR_VrrFPNkQJEkBwhBwdw9UnTsTu9SNs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/msVVn3XOU7NmR_VrrFPNkQJEkBwhBwdw9UnTsTu9SNs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t166.inf", 
		LAST);

	web_url("pnbd4hDK_2cvl_S6hCitqFNNTPqsModXCD66TIr2Kn0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/pnbd4hDK_2cvl_S6hCitqFNNTPqsModXCD66TIr2Kn0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t167.inf", 
		LAST);

	web_url("LQCohBBwDA3R-JLzJ4AlDpP5nHBCGOQCEVEK5x1FtUE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/LQCohBBwDA3R-JLzJ4AlDpP5nHBCGOQCEVEK5x1FtUE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t168.inf", 
		LAST);

	web_url("-U6JfEITec_lpqJjLeCstyg25WbUVKUFQ59xohFbJe0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/-U6JfEITec_lpqJjLeCstyg25WbUVKUFQ59xohFbJe0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t169.inf", 
		LAST);

	web_url("uVxFaSbldsbS_J6t8sG3JSZGdngXxWsFVUsNXiXzljg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/uVxFaSbldsbS_J6t8sG3JSZGdngXxWsFVUsNXiXzljg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t170.inf", 
		LAST);

	web_url("OoS_c62LQmM3reN5IxVFwsYHW754QyNkIVmxOlxrDXM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/OoS_c62LQmM3reN5IxVFwsYHW754QyNkIVmxOlxrDXM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t171.inf", 
		LAST);

	web_url("ItMlT2-sUWecPkk7-567cNvBHkYnPgVeuARi0cjc6iY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ItMlT2-sUWecPkk7-567cNvBHkYnPgVeuARi0cjc6iY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t172.inf", 
		LAST);

	web_url("PT6PdSX2LT9DRToX9sco-9hEcuDvGSddv7JApH5i7P8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/PT6PdSX2LT9DRToX9sco-9hEcuDvGSddv7JApH5i7P8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t173.inf", 
		LAST);

	web_url("0_oYU1mJm4BSOqhQZAzES5_qSazL_HzQ2sVVC9qv3W0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/0_oYU1mJm4BSOqhQZAzES5_qSazL_HzQ2sVVC9qv3W0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t174.inf", 
		LAST);

	web_url("eS8blTDPWR95cW2umspyrvXca9zb6tJZ3xZleNiSoYs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/eS8blTDPWR95cW2umspyrvXca9zb6tJZ3xZleNiSoYs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t175.inf", 
		LAST);

	web_url("5avJGeDJy6xQVJ5MqviWlZgtqH50GnBKl8I2XN0c7Nw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/5avJGeDJy6xQVJ5MqviWlZgtqH50GnBKl8I2XN0c7Nw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t176.inf", 
		LAST);

	web_url("qpvaZNSHZxyjhsvgR97cFs8o8vvrkSwSONcTw5SwEAk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/qpvaZNSHZxyjhsvgR97cFs8o8vvrkSwSONcTw5SwEAk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t177.inf", 
		LAST);

	web_url("vk5QTq4ouD_aVRzLhRXNNyAVmavjZNg-Q7X9yjSNmj0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/vk5QTq4ouD_aVRzLhRXNNyAVmavjZNg-Q7X9yjSNmj0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t178.inf", 
		LAST);

	web_url("VFrhuTOO4OrAAGaCYIG-BCOz0SePBTnEX6C_KvJe41g=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/VFrhuTOO4OrAAGaCYIG-BCOz0SePBTnEX6C_KvJe41g=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t179.inf", 
		LAST);

	web_url("RpJXx1JNQ_qmxTyyNO5BBCiNRB2JD2gTc16hxgFOPUI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/RpJXx1JNQ_qmxTyyNO5BBCiNRB2JD2gTc16hxgFOPUI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t180.inf", 
		LAST);

	web_url("RmyXpTNCXHXJxBthWmKlCN7kkSx4owUGTD2JktQ6Fuk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/RmyXpTNCXHXJxBthWmKlCN7kkSx4owUGTD2JktQ6Fuk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t181.inf", 
		LAST);

	web_url("pfkMihDh5AiM30TzAYSBVjd7l902E4RHgtccHxej19k=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/pfkMihDh5AiM30TzAYSBVjd7l902E4RHgtccHxej19k=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t182.inf", 
		LAST);

	web_url("meZ82A4wOXKLHoCKlLoD2WBllqZjKWya8-__7PcRXlI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/meZ82A4wOXKLHoCKlLoD2WBllqZjKWya8-__7PcRXlI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t183.inf", 
		LAST);

	web_url("seDEqlcmNM8wWPW__7g0o2lJlKjrpJorsXSqp3pFt4U=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/seDEqlcmNM8wWPW__7g0o2lJlKjrpJorsXSqp3pFt4U=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t184.inf", 
		LAST);

	web_url("hXMhQSNY6rycEcMEsVfaffoH-l0vYXAi1MvHDsj0JN4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/hXMhQSNY6rycEcMEsVfaffoH-l0vYXAi1MvHDsj0JN4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t185.inf", 
		LAST);

	web_url("9zZreEOGVQD7WUnvjIZcw8MA7D5JcTpD-5K5vPjfr0c=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/9zZreEOGVQD7WUnvjIZcw8MA7D5JcTpD-5K5vPjfr0c=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t186.inf", 
		LAST);

	web_url("Rg9qiUgynDHigMr5HjlyHjK9UdHylmqTbScW-ExmlMQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/Rg9qiUgynDHigMr5HjlyHjK9UdHylmqTbScW-ExmlMQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t187.inf", 
		LAST);

	web_url("SPbtt3fuYzi5-Cde8jI6ev6oda-CF0Z6rTsKlOjoFr8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/SPbtt3fuYzi5-Cde8jI6ev6oda-CF0Z6rTsKlOjoFr8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t188.inf", 
		LAST);

	web_url("0EF0kBUsbZzi_NXlOF0EpR3oGLJpv8YFxa0QAUgO9_4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/0EF0kBUsbZzi_NXlOF0EpR3oGLJpv8YFxa0QAUgO9_4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t189.inf", 
		LAST);

	web_url("vrs63ChOQX-dG7wkzUwCGjzenUgJWf1unuGIu9kkd4w=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/vrs63ChOQX-dG7wkzUwCGjzenUgJWf1unuGIu9kkd4w=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t190.inf", 
		LAST);

	web_url("F1vhmXygPyFrwVT7ekyYy5QzfIc7vDd9V8njmSTs9QI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/F1vhmXygPyFrwVT7ekyYy5QzfIc7vDd9V8njmSTs9QI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t191.inf", 
		LAST);

	web_url("eYVBeT8WD-NSGVyO1pYr7fkcevtG4nkvFfqa_x4bgYY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/eYVBeT8WD-NSGVyO1pYr7fkcevtG4nkvFfqa_x4bgYY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t192.inf", 
		LAST);

	web_url("bUbvkLmYtN-_VoC-ghreSclJCom4-f_eHbSmHXW36xA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/bUbvkLmYtN-_VoC-ghreSclJCom4-f_eHbSmHXW36xA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t193.inf", 
		LAST);

	web_url("4s4vKU1qNNnmfboC_eWLlKf8Mmc1-2pYxpGySEvnYm4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/4s4vKU1qNNnmfboC_eWLlKf8Mmc1-2pYxpGySEvnYm4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t194.inf", 
		LAST);

	web_url("IIyc1BK6AosiJkTGE2fakhpiS5xivMv7MikR1nizKnA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/IIyc1BK6AosiJkTGE2fakhpiS5xivMv7MikR1nizKnA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t195.inf", 
		LAST);

	web_url("r35GzRT-E-qLc1ZMyjny1o4CpE-WAQw1NvxyNVaFLwQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/r35GzRT-E-qLc1ZMyjny1o4CpE-WAQw1NvxyNVaFLwQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t196.inf", 
		LAST);

	web_url("5qgLF5aSSvUHxaKM6TJXSS6MEQ33kgvcn49vHL6zgWg=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/5qgLF5aSSvUHxaKM6TJXSS6MEQ33kgvcn49vHL6zgWg=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t197.inf", 
		LAST);

	web_url("NLF5N5_zwNVhHjEosY3Hvv4bb1Eto4ywsMkj8KuP9aU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/NLF5N5_zwNVhHjEosY3Hvv4bb1Eto4ywsMkj8KuP9aU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t198.inf", 
		LAST);

	web_url("qlTOLc2d8CzWDf5MjXe3aTWz_3D0alEEeKcCLTV7BPs=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/qlTOLc2d8CzWDf5MjXe3aTWz_3D0alEEeKcCLTV7BPs=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t199.inf", 
		LAST);

	web_url("KC-gh-2fTM32Gg0aFWbEyJ6-yb4jyFL7V5HzWSXurLE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/KC-gh-2fTM32Gg0aFWbEyJ6-yb4jyFL7V5HzWSXurLE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t200.inf", 
		LAST);

	web_url("mJ2dr_1-4w5kmlC5yiQ9b970mQk-ct8WS2Z7mSsffcU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/mJ2dr_1-4w5kmlC5yiQ9b970mQk-ct8WS2Z7mSsffcU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t201.inf", 
		LAST);

	web_url("9cBZC7nnZnXKgrtqlB9ysmOM89wkCFW1DmHMRAASvzE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/9cBZC7nnZnXKgrtqlB9ysmOM89wkCFW1DmHMRAASvzE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t202.inf", 
		LAST);

	web_url("E-yvLNjycQJgfiB-3axFTW39xycdiqK8l2VJMsYhG0M=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/E-yvLNjycQJgfiB-3axFTW39xycdiqK8l2VJMsYhG0M=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t203.inf", 
		LAST);

	web_url("opglPle-L2omnMRstHhNQ2VKSYk-qI9Sy10a3_RrlqE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/opglPle-L2omnMRstHhNQ2VKSYk-qI9Sy10a3_RrlqE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t204.inf", 
		LAST);

	web_url("FKVYa3c8SXNBybeIQR-UaUk_XFy0fYePiq2pgASF1DA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/FKVYa3c8SXNBybeIQR-UaUk_XFy0fYePiq2pgASF1DA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t205.inf", 
		LAST);

	web_url("TmcuuQ1m4PqSymOsz9_PkIlmQzKCLtMuLTtx9to7sMU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/TmcuuQ1m4PqSymOsz9_PkIlmQzKCLtMuLTtx9to7sMU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t206.inf", 
		LAST);

	web_url("NRM7-aGQoOmKorLZMnzFZx9Bxa9a3-mnp9zlEhrYt18=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/NRM7-aGQoOmKorLZMnzFZx9Bxa9a3-mnp9zlEhrYt18=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t207.inf", 
		LAST);

	web_url("-RNwXBeNiz1ZKS8uv8HuotjQjpJv2_cVyUekHv13MQ0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/-RNwXBeNiz1ZKS8uv8HuotjQjpJv2_cVyUekHv13MQ0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t208.inf", 
		LAST);

	web_url("4L0gYVkCRpYT4mV_mgYWvXf8X6iG7fZ1mZXYqor4BDY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/4L0gYVkCRpYT4mV_mgYWvXf8X6iG7fZ1mZXYqor4BDY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t209.inf", 
		LAST);

	web_url("WtdjIw8VXkl3WqG6fk4WbJyIElpQ7qWmpufi93DbpzY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/WtdjIw8VXkl3WqG6fk4WbJyIElpQ7qWmpufi93DbpzY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t210.inf", 
		LAST);

	web_url("9GcUv34uwQsto9Xt7UUceSjI8YwNgBdwRtJY6wTGpaQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/9GcUv34uwQsto9Xt7UUceSjI8YwNgBdwRtJY6wTGpaQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t211.inf", 
		LAST);

	web_url("flgDe0rVNZANXB34ANRPVXx1WMnHjPN_77qrtp3UobE=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/flgDe0rVNZANXB34ANRPVXx1WMnHjPN_77qrtp3UobE=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t212.inf", 
		LAST);

	web_url("yR7CpODQqGzqyydoZ-EMwcOvGqd6PZQIRJYgvvyME8I=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/yR7CpODQqGzqyydoZ-EMwcOvGqd6PZQIRJYgvvyME8I=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t213.inf", 
		LAST);

	web_url("tZ2lveNmDI594IznWjFCVUDSQIhiVWFZc5Ek9r1Hihw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/tZ2lveNmDI594IznWjFCVUDSQIhiVWFZc5Ek9r1Hihw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t214.inf", 
		LAST);

	web_url("pv27zXh4bjz1dOIdCeX7pLOYFqJZssY1R6i7vefuJAw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/pv27zXh4bjz1dOIdCeX7pLOYFqJZssY1R6i7vefuJAw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t215.inf", 
		LAST);

	web_url("MUcEllzsWbHlnEYHi3720oINNS1u5eYvW6piJjGdxmM=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/MUcEllzsWbHlnEYHi3720oINNS1u5eYvW6piJjGdxmM=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t216.inf", 
		LAST);

	web_url("d78eZXgCq_WeFYtnsMSOnHEaUtjbeEskTHQsFaihYL4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/d78eZXgCq_WeFYtnsMSOnHEaUtjbeEskTHQsFaihYL4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t217.inf", 
		LAST);

	web_url("ryniY2p8XiZSpXJ8q3va04k38eTastdSCnFKv_vrR9o=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ryniY2p8XiZSpXJ8q3va04k38eTastdSCnFKv_vrR9o=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t218.inf", 
		LAST);

	web_url("ED7VBClfnfsLPn_PVthjw7udcuvNnYeSNKTrb_FkAEA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ED7VBClfnfsLPn_PVthjw7udcuvNnYeSNKTrb_FkAEA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t219.inf", 
		LAST);

	web_url("Ek9DamsHmukyMCkt-2ulmRWotCfl9O6El-dUsqIJNYQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/Ek9DamsHmukyMCkt-2ulmRWotCfl9O6El-dUsqIJNYQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t220.inf", 
		LAST);

	web_url("iiTgk0IG7TJD7u_LCM2TtkMVrVmVG3sP4s3RKAR3yKA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/iiTgk0IG7TJD7u_LCM2TtkMVrVmVG3sP4s3RKAR3yKA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t221.inf", 
		LAST);

	web_url("vIPwP-76-SIOLfe7XFzARDMXxrOH0RSKpzKP4dfuB6M=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/vIPwP-76-SIOLfe7XFzARDMXxrOH0RSKpzKP4dfuB6M=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t222.inf", 
		LAST);

	web_url("fyUgFT9g7lnBPv2F313IFVoPYOxVoXOaBH549Gfg878=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/fyUgFT9g7lnBPv2F313IFVoPYOxVoXOaBH549Gfg878=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t223.inf", 
		LAST);

	web_url("J-VOZEKVehxZFOkWGAW_XSMDp2Kz9GdIfjXLz1zxseQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/J-VOZEKVehxZFOkWGAW_XSMDp2Kz9GdIfjXLz1zxseQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t224.inf", 
		LAST);

	web_url("A6Sp7Xgs2NnoDVwUBYdcGHeJMbEq6UehKW5ofeCEA-Y=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/A6Sp7Xgs2NnoDVwUBYdcGHeJMbEq6UehKW5ofeCEA-Y=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t225.inf", 
		LAST);

	web_url("rlwtTL4o_6jXDDDPQmANK7eGT_w5hAkanfLTdGbv3qk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/rlwtTL4o_6jXDDDPQmANK7eGT_w5hAkanfLTdGbv3qk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t226.inf", 
		LAST);

	web_url("iQtjiN_x90l2KGk7Lpzc1rbu6Ht-Kourodgwrqg9Hnw=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/iQtjiN_x90l2KGk7Lpzc1rbu6Ht-Kourodgwrqg9Hnw=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t227.inf", 
		LAST);

	web_url("jXakhpObY230SLWbMHZtOcXr9yCjSY_Vo6bdym4a280=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/jXakhpObY230SLWbMHZtOcXr9yCjSY_Vo6bdym4a280=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t228.inf", 
		LAST);

	web_url("fyED5eO7g4mwjD_PAQrkG2VrC_hki07zrYwNpw3jsCI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/fyED5eO7g4mwjD_PAQrkG2VrC_hki07zrYwNpw3jsCI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t229.inf", 
		LAST);

	web_url("KX0_ONUbyvS_JMwjjdsdhU8smKHbFc6W404KL8NTpn4=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/KX0_ONUbyvS_JMwjjdsdhU8smKHbFc6W404KL8NTpn4=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t230.inf", 
		LAST);

	web_url("HLvomnorGiZHnyvhkuoA_viz21LwawKzFsMf87VwjZY=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/HLvomnorGiZHnyvhkuoA_viz21LwawKzFsMf87VwjZY=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t231.inf", 
		LAST);

	web_url("DjQuZzL_o7v9kHrdEkG_Abv53jO-1nUgGYUSTBQQ0z0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/DjQuZzL_o7v9kHrdEkG_Abv53jO-1nUgGYUSTBQQ0z0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t232.inf", 
		LAST);

	web_url("ixaMX2Rb9z7GHvO5_2XtMCUuFztz94TzXdBx2rMIxVU=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ixaMX2Rb9z7GHvO5_2XtMCUuFztz94TzXdBx2rMIxVU=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t233.inf", 
		LAST);

	web_url("UBmLfmdS5K3YIyF9sbAcGZF2KDbdLkpBHahxyE9UABk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/UBmLfmdS5K3YIyF9sbAcGZF2KDbdLkpBHahxyE9UABk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t234.inf", 
		LAST);

	web_url("62BlqAShvNjlPkGwQEhvYgmtnFu9lZdhwvLi_GjOzzA=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/62BlqAShvNjlPkGwQEhvYgmtnFu9lZdhwvLi_GjOzzA=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t235.inf", 
		LAST);

	web_url("5Cf162CQGSRp88fqK02aZKhlQN7zwa4BjF8nRqtEo0M=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/5Cf162CQGSRp88fqK02aZKhlQN7zwa4BjF8nRqtEo0M=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t236.inf", 
		LAST);

	web_url("lnykqXOZPyceZ50yonS3iRN9t4ByT5ZCBF9sCEtO4J0=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/lnykqXOZPyceZ50yonS3iRN9t4ByT5ZCBF9sCEtO4J0=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t237.inf", 
		LAST);

	web_url("XsV3Vvicwo8ztp03dUlf_CGru1-FucVD0N6_7LhIXKc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/XsV3Vvicwo8ztp03dUlf_CGru1-FucVD0N6_7LhIXKc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t238.inf", 
		LAST);

	web_url("YrolRjEjx_O60B-Xc8HjFRcphpcVkjs1VUxWk8Uaflc=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/YrolRjEjx_O60B-Xc8HjFRcphpcVkjs1VUxWk8Uaflc=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t239.inf", 
		LAST);

	web_url("fhYxFI7bxyjE4lb4mw3ARoij-qqDhOoBHNBErGis6QI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/fhYxFI7bxyjE4lb4mw3ARoij-qqDhOoBHNBErGis6QI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t240.inf", 
		LAST);

	web_url("ypk9VVawPEEcnIW71nu6TESs1YW_78RlNcWNYnvGae8=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/ypk9VVawPEEcnIW71nu6TESs1YW_78RlNcWNYnvGae8=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t241.inf", 
		LAST);

	web_url("jtrdOKf7HZ7C7FmbN8iMIncDw8IUjKJTsEQ5P2r22ko=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/jtrdOKf7HZ7C7FmbN8iMIncDw8IUjKJTsEQ5P2r22ko=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t242.inf", 
		LAST);

	web_url("jzVOUUiUkeAnbyYN2JkdVFMPJHnOdbBK6xBZwzQKMgk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/jzVOUUiUkeAnbyYN2JkdVFMPJHnOdbBK6xBZwzQKMgk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t243.inf", 
		LAST);

	web_url("6Eb-WDv6dO4XmpNrRgPBL9JK6Eu3WDvBa_U_hUE-J4E=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/6Eb-WDv6dO4XmpNrRgPBL9JK6Eu3WDvBa_U_hUE-J4E=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t244.inf", 
		LAST);

	web_url("t7M80cRyU3kHSszP86_hnX0BObOXJLebRuW1qQaD3Pk=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/t7M80cRyU3kHSszP86_hnX0BObOXJLebRuW1qQaD3Pk=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t245.inf", 
		LAST);

	web_url("N3QvoomSu5tgVA4AQpftZm_mdJzaVE9vdonN4D2nAmI=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/N3QvoomSu5tgVA4AQpftZm_mdJzaVE9vdonN4D2nAmI=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t246.inf", 
		LAST);

	web_url("YIbgRiF33VuE5NdyZ5VQQQEYdXUqR5o_O40Sbjw7Y60=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/YIbgRiF33VuE5NdyZ5VQQQEYdXUqR5o_O40Sbjw7Y60=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t247.inf", 
		LAST);

	web_url("vUDbyXweMnPZ7xE_wpI9W_evyJ1SB2Jk30yZ0_8-rlQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/vUDbyXweMnPZ7xE_wpI9W_evyJ1SB2Jk30yZ0_8-rlQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t248.inf", 
		LAST);

	web_url("UOic4P8WS7auHOmBZEDyP6fSlgdjorR_XE5a3bh3rcQ=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/UOic4P8WS7auHOmBZEDyP6fSlgdjorR_XE5a3bh3rcQ=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t249.inf", 
		LAST);

	web_url("wDLqb9IJOCJe5dV9vqLjGmm8YQK2KI52KM0gINRn3oo=.chunk", 
		"URL=https://sba.cdn.yandex.net/chunks/ydx-malware-shavar/wDLqb9IJOCJe5dV9vqLjGmm8YQK2KI52KM0gINRn3oo=.chunk", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t250.inf", 
		LAST);

	web_concurrent_end(NULL);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	return 0;
}