Action()
{

	/*Connection ID 0 received buffer WebSocketReceive0*/
	
	lr_start_transaction("Cancel_departure");
	
	lr_think_time(5);

	lr_start_transaction("login");

	
	web_reg_save_param("userSession",
		"LB/IC=userSession\" value=\"",
		"RB/IC=\"/>",
		LAST);
	
	web_url("WebTours", 
		"URL=http://127.0.0.1:1080/WebTours", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={userSession}", ENDITEM, 
		"Name=username", "Value={username}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=login.x", "Value=55", ENDITEM, 
		"Name=login.y", "Value=14", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("view_ticket");
	

	web_url("Itinerary Button",
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary",
		"TargetFrame=body",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home",
		"Snapshot=t13.inf",
		"Mode=HTML",
		LAST);


	lr_end_transaction("view_ticket",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Cancel_ticket");


	web_submit_data("itinerary.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=flightID", "Value=1194-787-JB", ENDITEM, 
		"Name=2", "Value=on", ENDITEM, 
		"Name=flightID", "Value=251447879-1595-JB", ENDITEM, 
		"Name=removeFlights.x", "Value=70", ENDITEM, 
		"Name=removeFlights.y", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		LAST);

	lr_end_transaction("Cancel_ticket",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Home_page");

	web_url("Home Button",
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=menus",
		"TargetFrame=body",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=itinerary",
		"Snapshot=t17.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("Home_page",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("log_out");

	web_url("SignOff Button",
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1",
		"TargetFrame=body",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home",
		"Snapshot=t18.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("log_out",LR_AUTO);

	lr_end_transaction("Cancel_departure",LR_AUTO);

	return 0;
}