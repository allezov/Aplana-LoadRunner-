Action()
{

    lr_start_transaction("buy_and_view_ticket");

    web_concurrent_start(NULL);

   
    web_concurrent_end(NULL);

    lr_start_transaction("login");

    web_add_auto_header("DNT", 
        "1");

    web_add_header("Origin", 
        "http://127.0.0.1:1080");


    lr_think_time(5);
        

    web_submit_data("login.pl", 
        "Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
        "Snapshot=t14.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=userSession", "Value=127663.127663021zfzzzHcpVcQVzzzHDQtAApADcHHf", ENDITEM, 
        "Name=username", "Value=jojo", ENDITEM, 
        "Name=password", "Value=bean", ENDITEM, 
        "Name=login.x", "Value=44", ENDITEM, 
        "Name=login.y", "Value=5", ENDITEM, 
        "Name=JSFormSubmit", "Value=off", ENDITEM, 
        LAST);
    
   

    lr_end_transaction("login",LR_AUTO);

    lr_start_transaction("Flight");


    lr_think_time(5);

   /*Correlation comment - Do not change!  Original value='seatType' Name ='Name' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=Name",
		"TagName=input",
		"Extract=name",
		"Type=radio",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/reservations.pl*",
		LAST);

 web_url("Search Flights Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
        "Snapshot=t15.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("Flight",LR_AUTO);

    lr_start_transaction("Check_departure");

    web_add_auto_header("Origin", 
        "http://127.0.0.1:1080");

    lr_think_time(5);

    web_submit_data("reservations.pl",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl?page=welcome",
		"Snapshot=t16.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=depart", "Value=Paris", ENDITEM,
		"Name=departDate", "Value=12/11/2019", ENDITEM,
		"Name=arrive", "Value=Los Angeles", ENDITEM,
		"Name=returnDate", "Value=19/12/2020", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=seatPref", "Value=Window", ENDITEM,
		"Name={Name}", "Value=First", ENDITEM,
		"Name=findFlights.x", "Value=64", ENDITEM,
		"Name=findFlights.y", "Value=8", ENDITEM,
		"Name=.cgifields", "Value=roundtrip", ENDITEM,
		"Name=.cgifields", "Value={Name}", ENDITEM,
		"Name=.cgifields", "Value=seatPref", ENDITEM,
		LAST);

    lr_think_time(5);

    web_submit_data("reservations.pl_2",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Snapshot=t17.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=outboundFlight", "Value=430;822;12/11/2019", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name={Name}", "Value=First", ENDITEM,
		"Name=seatPref", "Value=Window", ENDITEM,
		"Name=reserveFlights.x", "Value=62", ENDITEM,
		"Name=reserveFlights.y", "Value=7", ENDITEM,
		LAST);

    lr_end_transaction("Check_departure",LR_AUTO);

    lr_start_transaction("details");

    lr_think_time(5);

    web_submit_data("reservations.pl_3",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Snapshot=t18.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=firstName", "Value=Jojo", ENDITEM,
		"Name=lastName", "Value=Bean", ENDITEM,
		"Name=address1", "Value=Zabugornaya", ENDITEM,
		"Name=address2", "Value=Inostrannaya", ENDITEM,
		"Name=pass1", "Value=Jojo Bean", ENDITEM,
		"Name=creditCard", "Value=88005553535", ENDITEM,
		"Name=expDate", "Value=55", ENDITEM,
		"Name=oldCCOption", "Value=", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name={Name}", "Value=First", ENDITEM,
		"Name=seatPref", "Value=Window", ENDITEM,
		"Name=outboundFlight", "Value=430;822;12/11/2019", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=returnFlight", "Value=", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=buyFlights.x", "Value=47", ENDITEM,
		"Name=buyFlights.y", "Value=8", ENDITEM,
		"Name=.cgifields", "Value=saveCC", ENDITEM,
		LAST);

    lr_end_transaction("details",LR_AUTO);

    lr_start_transaction("View_ticket");


    lr_think_time(5);

    web_url("Itinerary Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=flights", 
        "Snapshot=t19.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("View_ticket",LR_AUTO);

    lr_start_transaction("home_page");


    lr_think_time(5);

    web_url("Home Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=menus", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
        "Snapshot=t20.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("home_page",LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("Log_out");

    web_url("SignOff Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
        "Snapshot=t21.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("Log_out",LR_AUTO);

    lr_end_transaction("buy_and_view_ticket",LR_AUTO);

    return 0;
}
