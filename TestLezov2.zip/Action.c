Action()
{

    lr_start_transaction("Web_Tours_info");

    lr_start_transaction("Login");

  
    lr_think_time(5);

    web_submit_data("login.pl", 
        "Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
        "Snapshot=t13.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=userSession", "Value=127662.807533414zfzzzffpzzcfDQDQQpQDDQHf", ENDITEM, 
        "Name=username", "Value=jojo", ENDITEM, 
        "Name=password", "Value=bean", ENDITEM, 
        "Name=login.x", "Value=72", ENDITEM, 
        "Name=login.y", "Value=6", ENDITEM, 
        "Name=JSFormSubmit", "Value=off", ENDITEM, 
        LAST);

    web_concurrent_start(NULL);

  

    web_concurrent_end(NULL);

    lr_end_transaction("Login",LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("Home_page");

    web_url("Home Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=menus", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
        "Snapshot=t16.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("Home_page",LR_AUTO);

    lr_start_transaction("Itinerary_page");

   

    lr_think_time(5);

    web_url("Itinerary Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
        "Snapshot=t17.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("Itinerary_page",LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("Sign_Off");

    web_url("SignOff Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
        "Snapshot=t18.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("Sign_Off",LR_AUTO);

    lr_end_transaction("Web_Tours_info",LR_AUTO);

    return 0;
}
