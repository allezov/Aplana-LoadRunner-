Action()
{

    web_add_header("X-HTTP-Method-Override", 
        "POST");

    web_concurrent_start(NULL);


    web_concurrent_end(NULL);

    lr_start_transaction("ticket_to_Los_Angeles");

    lr_start_transaction("login");



    lr_think_time(5);
    
    
    web_submit_data("login.pl", 
        "Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
        "Snapshot=t615.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=userSession", "Value=127662.581611989zfzzzttpAtVzzzzHDQDQQpiztcf", ENDITEM, 
        "Name=username", "Value=jojo", ENDITEM, 
        "Name=password", "Value=bean", ENDITEM, 
        "Name=login.x", "Value=64", ENDITEM, 
        "Name=login.y", "Value=14", ENDITEM, 
        "Name=JSFormSubmit", "Value=off", ENDITEM, 
        LAST);

	

    lr_end_transaction("login",LR_AUTO);

    lr_start_transaction("flight");


    lr_think_time(5);

   /*Correlation comment - Do not change!  Original value='seatPref' Name ='Name' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=Name",
		"TagName=input",
		"Extract=name",
		"Type=radio",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/reservations.pl*",
		LAST);

 web_url("Search Flights Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
        "Snapshot=t616.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("flight",LR_AUTO);

    lr_start_transaction("find flight");


    lr_think_time(5);

    web_submit_data("reservations.pl",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl?page=welcome",
		"Snapshot=t617.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=depart", "Value=Denver", ENDITEM,
		"Name=departDate", "Value=12/11/2019", ENDITEM,
		"Name=arrive", "Value=London", ENDITEM,
		"Name=returnDate", "Value=12/12/2019", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name={Name}", "Value=Window", ENDITEM,
		"Name=seatType", "Value=Coach", ENDITEM,
		"Name=findFlights.x", "Value=71", ENDITEM,
		"Name=findFlights.y", "Value=8", ENDITEM,
		"Name=.cgifields", "Value=roundtrip", ENDITEM,
		"Name=.cgifields", "Value=seatType", ENDITEM,
		"Name=.cgifields", "Value={Name}", ENDITEM,
		LAST);

    lr_think_time(5);

    web_submit_data("reservations.pl_2",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Snapshot=t618.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=outboundFlight", "Value=021;301;12/11/2019", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=seatType", "Value=Coach", ENDITEM,
		"Name={Name}", "Value=Window", ENDITEM,
		"Name=reserveFlights.x", "Value=67", ENDITEM,
		"Name=reserveFlights.y", "Value=9", ENDITEM,
		LAST);



    lr_think_time(5);

    web_submit_data("reservations.pl_3",
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl",
		"Snapshot=t619.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=firstName", "Value=Jojo", ENDITEM,
		"Name=lastName", "Value=Bean", ENDITEM,
		"Name=address1", "Value=serp", ENDITEM,
		"Name=address2", "Value=serp2", ENDITEM,
		"Name=pass1", "Value=Jojo Bean", ENDITEM,
		"Name=creditCard", "Value=123456789", ENDITEM,
		"Name=expDate", "Value=11", ENDITEM,
		"Name=oldCCOption", "Value=", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=seatType", "Value=Coach", ENDITEM,
		"Name={Name}", "Value=Window", ENDITEM,
		"Name=outboundFlight", "Value=021;301;12/11/2019", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=returnFlight", "Value=", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=buyFlights.x", "Value=57", ENDITEM,
		"Name=buyFlights.y", "Value=9", ENDITEM,
		"Name=.cgifields", "Value=saveCC", ENDITEM,
		LAST);

    lr_think_time(5);

    web_submit_data("reservations.pl_4", 
        "Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
        "Snapshot=t620.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=Book Another.x", "Value=34", ENDITEM, 
        "Name=Book Another.y", "Value=6", ENDITEM, 
        LAST);

    lr_end_transaction("find flight",LR_AUTO);

    lr_start_transaction("itinerary");



    lr_think_time(5);

    web_url("Itinerary Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=flights", 
        "Snapshot=t621.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("itinerary",LR_AUTO);

    lr_think_time(5);

    lr_start_transaction("logOut");

    web_url("SignOff Button", 
        "URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
        "TargetFrame=body", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
        "Snapshot=t622.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("logOut",LR_AUTO);

    lr_end_transaction("ticket_to_Los_Angeles",LR_AUTO);

    return 0;
}
